import SwiftUI
import UserNotifications

struct HomeView: View {
    @AppStorage("hasSeenOnboarding") private var hasSeenOnboarding = false
    @State var showContinueAlert = false
    
    @State private var showGoToSettingsAlert = false
    @State private var showContinueWithoutNotificationsAlert = false
    @State private var permissionStatusText: String? = nil
    @EnvironmentObject var controller: NotificationController
    
    var body: some View {
        NavigationStack
        {
            ScrollView
            {
                VStack(alignment: .leading, spacing: 16)
                {
                    Text("Welcome to VitalityTracker!")
                        .font(.title2)
                        .fontWeight(.bold)
                    
                    Text("""
                         Your all-in-one health and wellbeing companion.
                         This app is intended to help you stay on track with your daily goals and enforce healthy to support your vitality!
                         """)
                    .font(.title3)
                    
                    Divider()
                    
                    Text("""
                        To start, it is recommended to press the button below to allow VitalityTracker to send you notifications when you
                        need to complete your daily habits. 
                        
                        Don't worry, you can manually turn off notifications whenever you like by navigation to:
                        Settings > Apps > VitalityTracker > Notifications.
                        """)
                    .font(.title3)
                    
                    Button("Allow Notifications")
                    {
                        controller.requestPermission{granted in
                            hasSeenOnboarding = true
                        }
                    }
                    .frame(maxWidth: .infinity)
                    .buttonStyle(.borderedProminent)
                    
                    Button("Continue")
                    {
                        showContinueAlert = true
                    }
                    .frame(maxWidth: .infinity)
                    .buttonStyle(.bordered)
                    
                    Spacer()

                }.padding()
                    .alert("Are you sure you want to ontinue without enabling notifications?", isPresented: $showContinueAlert)
                {
                    Button("No", role: .cancel) {}
                    Button("Yes")
                    {
                        hasSeenOnboarding = true
                    }
                }

                
            }
        }
    }
}

#Preview {
    HomeView()
        .tint(.blue)
        //.previewDisplayName("Light mode")
}

